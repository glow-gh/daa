import unicodedata
import re

file = open("RINAP_4_1_no_line_numbers.txt", "r+")
data1 = file.read()

#removing \xa0 (hard spaces) from .txt file
data = unicodedata.normalize("NFKD", data1)
print (data)

#How many words are in the file?
#words = data.split() 
#print('Total number of words in text file :', len(words)) 

#Count a specific word in the file
#LUGAL = data.count("LUGAL") 
#print('Number of LUGAL symbol in text:', LUGAL)

#First instance of a word (only yes or no)
#searchLUGAL = re.search("LUGAL",data)
#print(searchLUGAL)

#Find all instances of word
#findallLUGAL = re.findall("LUGAL",data)
#print(findallLUGAL)

#Regex of a word
#findallRegex = re.findall(r"LUGAL.+",data) #This is 'LUGAL' with any number of characters afterwards
#print(findallRegex)

# Regular expression that matches potentially interesting words
# ^     string begins with
# $     string ends with
# .     any character
# +     repeat previous character n times
# (x|y) disjunction, i.e. X or Y,
