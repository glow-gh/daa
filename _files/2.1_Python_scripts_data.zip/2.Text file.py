import unicodedata
import re

file = open("RINAP_4_1_no_line_numbers.txt", "r+")
data1 = file.read()

#removing \xa0 (hard spaces) from .txt file
data = unicodedata.normalize("NFKD", data1)
#print (data)

#How many words are in the file?
#words = data.split() 
#print('Total number of words in text file :', len(words)) 

#Count a specific word in the file
#lugal = data.count("LUGAL") 
#print('Number of LUGAL symbol in text:', lugal)

#First instance of a word (only yes or no)
#searchlugal = re.search("MUNUS",data)
#print(searchlugal)

#Find all instances of word
#findalllugal = re.findall("MUNUS",data)
#print(findalllugal)

#Regex of a word
#findallregex = re.findall(r"MUNUS.*?[ $]",data) #This is 'LUGAL' with anything afterwards that is part of the word
#print(findallregex)

# Regular expression that matches potentially interesting words
# *     zero or more times
# ?     tries to find the shortest possible string
# ^     string begins with
# $     string ends with
# .     any character
# +     repeat previous character 1+ times
# (x|y) disjunction, i.e. X or Y,

#number of results
#number_of_elements = len(findallregex)
#print(number_of_elements)

#%age of the whole text
#quotient = number_of_elements / len(words)
#percentage = quotient * 100
#print(percentage)

