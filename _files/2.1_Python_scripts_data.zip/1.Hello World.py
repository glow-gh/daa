print("Hello, world!")

