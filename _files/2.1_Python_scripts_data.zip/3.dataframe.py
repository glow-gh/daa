import pandas as pd

#df = pd.read_csv('OldPMIDataExample.csv', sep='\t')#when columns are separated with a comma, use ',')

#print(df.to_string()) #this is an enormous table, so it takes forever to load. We won't do this today. 

#only one column
#words = df[['word1']]
#print(words)

#add two columns together
#we already have one column (words), so we need to make another
#words2 = df[['word2']]
#print(words2)
#rename s2 columne to 'word1'
#words2.columns = ['word1']
#Table = pd.concat([words, words2], ignore_index=True)
#print(Table)

#remove duplicates
#NoDuplicates = Table.drop_duplicates(subset=['word1'], keep='last')
#print(NoDuplicates)

#re-order the index to start from 1
#NewOrder = NoDuplicates.reset_index(drop=True)
#print(NewOrder)

#add ID column (the row index plus one)
#NewOrder['Id'] = NewOrder.index + 1 #needs to be the same as the one before
#print(NewOrder)

#filtering according to a column
#ilu = df[df['word2']=='ilu[god]N']
#print(ilu)

#saving the file
#savefile =  'dataframe.csv'
#with open(savefile, 'w', encoding="utf-8") as w:
 #   ilu.to_csv(w, index=True) #beginning of this is the last dataframe we make
